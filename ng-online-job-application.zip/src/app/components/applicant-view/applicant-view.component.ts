import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-view',
  templateUrl: './applicant-view.component.html',
  styleUrls: ['./applicant-view.component.css']
})
export class ApplicantViewComponent implements OnInit {
  applicantData
  constructor() { }

  ngOnInit() {
    this.applicantData = JSON.parse(localStorage.getItem('applicant_data'));

  }

}
