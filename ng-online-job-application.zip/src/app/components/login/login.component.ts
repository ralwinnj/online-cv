import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  isLoading = false;

  loginForm

  constructor(private fb: FormBuilder, private router: Router) { }
  ngOnInit() {
    this.loginForm = this.fb.group({
      email: [''],
      password: [''],
      rememberMe: ['']

    })
  }
  submitForm() {
    console.log('submitting....')
    this.isLoading = true;
    setTimeout(() => {
      this.isLoading = false;
      this.router.navigate(['applicant-form'])
    }, 3000);
    console.log('this is the form to be submitted: ', this.loginForm);
  }

}
