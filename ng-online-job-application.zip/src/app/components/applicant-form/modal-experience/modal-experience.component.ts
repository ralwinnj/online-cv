import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-experience',
  templateUrl: './modal-experience.component.html',
  styleUrls: ['./modal-experience.component.css']
})
export class ModalExperienceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
