import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

import { NgbModal, ModalDismissReasons, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-applicant-form',
  templateUrl: './applicant-form.component.html',
  styleUrls: ['./applicant-form.component.css']
})

export class ApplicantFormComponent implements OnInit {

  isLoading = false;

  personalForm: FormGroup;
  educationForm: FormGroup;
  experienceForm: FormGroup;

  personal: {};

  experience: { title: any; company: any; location: any; startDate: any; endDate: any; description: any; }[] = [];

  education: { yearCompleted: any; institution: any; fieldOfStudy: any; qualificationType: any; }[] = [];

  qualifications: string[];

  constructor(
    private modalService: NgbModal,
    private calendar: NgbCalendar,
    private fb: FormBuilder,
    private router: Router) {
  }

  ngOnInit() {
    this.personalForm = this.fb.group({
      gender: [],
      title: [],
      ethnicity: [],
      firstName: [],
      lastName: [],
      disability: [],
      birthDate: [],
      citizenship: [],
      idNumber: [],
      address: [],
      phoneNumber: [],
      emailAddress: []
    })

    this.experienceForm = this.fb.group({
      title: [],
      company: [],
      location: [],
      currentPlaceOfWork: [],
      startDate: [],
      endDate: [],
      description: [],

    });

    this.educationForm = this.fb.group({
      yearCompleted: [],
      institution: [],
      fieldOfStudy: [],
      qualificationType: [],
    });

    this.qualifications = [
      'Matric',
      'Certificate',
      'N 1',
      'N 2',
      'N 3',
      'N 4',
      'N 5',
      'N 6',
      'Diploma',
      'Bachelors',
      'Masters',
      'Honours',
      'Doctorate',
    ]
  }

  open(content) {
    this.modalService.open(content, {
      ariaLabelledBy: "modal-title",
      windowClass: 'fadeIn wow',
      size: 'lg',
      centered: true
    }).result
      .then((result) => {
        // SUCCESS LOGIC COMES HERE!!!!
        console.log("closed successfully!")
      }, (reason) => {
        console.log(this.getDismissReason(reason));
      });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  public saveExperience() {
    const data = {
      title: this.experienceForm.value.title,
      company: this.experienceForm.value.company,
      location: this.experienceForm.value.location,
      startDate: this.experienceForm.value.startDate,
      endDate: this.experienceForm.value.endDate,
      description: this.experienceForm.value.description
    }

    this.experience.push(data);
    this.experienceForm.reset();
  }

  public saveEducation() {
    const data = {
      yearCompleted: this.educationForm.value.yearCompleted,
      institution: this.educationForm.value.institution,
      fieldOfStudy: this.educationForm.value.fieldOfStudy,
      qualificationType: this.educationForm.value.qualificationType,
    }

    this.education.push(data);
    this.educationForm.reset();
  }

  public saveDetails() {

    console.log('submitting....')
    this.isLoading = true;
    setTimeout(() => {
      this.isLoading = false;
      this.personal = {
        gender: this.personalForm.value.gender,
        title: this.personalForm.value.title,
        ethnicity: this.personalForm.value.ethnicity,
        firstName: this.personalForm.value.firstName,
        lastName: this.personalForm.value.lastName,
        disability: this.personalForm.value.disability,
        birthDate: this.personalForm.value.birthDate,
        citizenship: this.personalForm.value.citizenship,
        idNumber: this.personalForm.value.idNumber,
        address: this.personalForm.value.address,
        phoneNumber: this.personalForm.value.phoneNumber,
        emailAddress: this.personalForm.value.emailAddress,
        experience: this.experience,
        education: this.education
      }

      localStorage.setItem('applicant_data', JSON.stringify(this.personal));
      console.log('personal details', this.personal);
      console.log('experience details', this.experience);
      console.log('education details', this.education);
      // this.router.navigate(['applicant-view'])
    }, 3000);
  }

}
