import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ApplicantViewComponent } from './components/applicant-view/applicant-view.component';
import { ApplicantListComponent } from './components/applicant-list/applicant-list.component';
import { ApplicantFormComponent } from './components/applicant-form/applicant-form.component';
import { LoginComponent } from './components/login/login.component';

const routes: Routes = [
  {
    path: '',
    component: ApplicantFormComponent
  },
  {
    path: 'applicant-form',
    component: ApplicantFormComponent
  },
  {
    path: 'applicant-list',
    component: ApplicantListComponent
  },
  {
    // path: 'applicant-view/:id',
    path: 'applicant-view',
    component: ApplicantViewComponent
  },
  {
    path: 'login',
    component: LoginComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const AppModuleList = [
  ApplicantViewComponent,
  ApplicantListComponent,
  ApplicantFormComponent,
  LoginComponent,
];
