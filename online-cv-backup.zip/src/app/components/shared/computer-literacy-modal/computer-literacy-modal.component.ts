import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-computer-literacy-modal',
  templateUrl: './computer-literacy-modal.component.html',
  styleUrls: ['./computer-literacy-modal.component.css']
})
export class ComputerLiteracyModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
