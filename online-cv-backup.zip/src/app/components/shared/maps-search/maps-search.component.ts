import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maps-search',
  templateUrl: './maps-search.component.html',
  styleUrls: ['./maps-search.component.css']
})
export class MapsSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
