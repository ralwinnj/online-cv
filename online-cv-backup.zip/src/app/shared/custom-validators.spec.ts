import { CustomValidators } from './custom-validators';

describe('CustomValidators', () => {
  it('should create an instance', () => {
    expect(new CustomValidators()).toBeTruthy();
  });
});
